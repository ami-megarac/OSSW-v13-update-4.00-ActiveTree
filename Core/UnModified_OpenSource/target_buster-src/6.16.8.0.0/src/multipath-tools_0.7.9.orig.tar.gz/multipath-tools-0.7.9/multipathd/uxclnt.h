int uxclnt(char * inbuf, unsigned int timeout);
