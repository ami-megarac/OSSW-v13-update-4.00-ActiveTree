int assemble_map (struct multipath *, char *, int);
int disassemble_map (vector, char *, struct multipath *, int);
int disassemble_status (char *, struct multipath *);
