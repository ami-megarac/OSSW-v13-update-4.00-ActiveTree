#ifndef _HWTABLE_H
#define _HWTABLE_H

int setup_default_hwtable (vector hw);

#endif /* _HWTABLE_H */
