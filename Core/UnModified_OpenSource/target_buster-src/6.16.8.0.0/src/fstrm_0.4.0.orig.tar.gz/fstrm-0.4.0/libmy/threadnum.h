#ifndef MY_THREADNUM_H
#define MY_THREADNUM_H

void my_threadnum_register(void);
int my_threadnum(void);

#endif /* MY_THREADNUM_H */
