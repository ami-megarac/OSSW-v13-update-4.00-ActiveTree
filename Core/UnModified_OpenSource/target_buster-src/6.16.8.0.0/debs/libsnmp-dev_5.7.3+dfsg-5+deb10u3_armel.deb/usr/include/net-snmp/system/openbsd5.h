/* openbsd5 is a superset of all since openbsd3 */
#include "openbsd4.h"
#define openbsd4 openbsd4
