#!/usr/local/bin/python2.6
"/usr/local/bin/python2.6 hardcoded in shebang"
