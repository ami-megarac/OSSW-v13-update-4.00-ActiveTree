print("you just imported foo.baz from %s" % __file__)
