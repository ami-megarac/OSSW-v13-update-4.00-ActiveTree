#!/usr/local/bin/python
"/usr/local in shebang"
