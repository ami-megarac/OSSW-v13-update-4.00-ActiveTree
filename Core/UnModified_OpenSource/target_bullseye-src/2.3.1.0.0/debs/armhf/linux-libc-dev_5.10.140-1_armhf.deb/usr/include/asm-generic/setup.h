/* SPDX-License-Identifier: GPL-2.0 WITH Linux-syscall-note */
#ifndef __ASM_GENERIC_SETUP_H
#define __ASM_GENERIC_SETUP_H

#define COMMAND_LINE_SIZE	512

#endif	/* __ASM_GENERIC_SETUP_H */
