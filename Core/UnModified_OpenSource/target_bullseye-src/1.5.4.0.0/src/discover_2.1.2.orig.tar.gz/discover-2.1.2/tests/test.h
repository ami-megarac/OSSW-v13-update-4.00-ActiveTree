/* $Progeny$ */

Suite *
make_device_suite(void);
Suite *
make_xml_suite(void);
