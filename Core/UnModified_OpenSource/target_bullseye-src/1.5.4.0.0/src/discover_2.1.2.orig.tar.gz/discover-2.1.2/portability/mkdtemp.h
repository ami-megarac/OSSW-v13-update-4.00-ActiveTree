/* $Progeny$ */

extern char * mkdtemp(char *TEMPLATE);
