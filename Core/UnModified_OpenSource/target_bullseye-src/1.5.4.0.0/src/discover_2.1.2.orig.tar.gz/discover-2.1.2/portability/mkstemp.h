/* $Progeny$ */

int mkstemp(char *path);
