/* $Progeny$ */

extern void *alloca(unsigned int size);
