/* version.h 1.94 2000/10/03 17:55:48 (David Hinds) */

#define CS_RELEASE "3.1.22"
#define CS_RELEASE_CODE 0x3116
