#ifndef _LUA_DEB_MULTIARCH_
#define _LUA_DEB_MULTIARCH_
#define DEB_HOST_MULTIARCH "arm-linux-gnueabihf"
#endif
