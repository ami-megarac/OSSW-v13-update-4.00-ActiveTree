# stunnel known bugs


* Shared library for transparent proxy does not support IPv6.
