PyHamcrest documentation
========================

Contents:

.. toctree::
    :maxdepth: 1

    tutorial
    custom_matchers
    library
    integration
    core

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

