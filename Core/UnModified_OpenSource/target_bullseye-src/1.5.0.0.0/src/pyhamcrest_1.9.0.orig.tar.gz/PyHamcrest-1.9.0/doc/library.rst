Matcher Library
===============

Library of Matcher implementations.

.. toctree::

    object_matchers
    number_matchers
    text_matchers
    logical_matchers
    sequence_matchers
    dictionary_matchers
    decorator_matchers
