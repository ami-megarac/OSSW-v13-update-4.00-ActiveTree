Integration with PyUnit and Other Libraries
===========================================

assert_that
-----------

.. automodule:: hamcrest.core.assert_that
    :exclude-members: assert_that
.. autofunction:: assert_that(actual, matcher[, reason])

match_equality
--------------

.. automodule:: hamcrest.library.integration.match_equality
