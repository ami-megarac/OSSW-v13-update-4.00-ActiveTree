.. Define the common option -h

**-h, --help**      show the usage message

