.. Define the common option -L

**-L, --Lid**   The address specified is a LID

