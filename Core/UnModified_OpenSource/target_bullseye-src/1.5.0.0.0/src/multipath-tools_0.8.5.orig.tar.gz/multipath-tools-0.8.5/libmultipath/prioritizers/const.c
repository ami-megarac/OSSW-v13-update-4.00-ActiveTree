#include <stdio.h>

#include "prio.h"

int getprio(__attribute__((unused)) struct path * pp,
	    __attribute__((unused)) char * args,
	    __attribute__((unused)) unsigned int timeout)
{
	return 1;
}
