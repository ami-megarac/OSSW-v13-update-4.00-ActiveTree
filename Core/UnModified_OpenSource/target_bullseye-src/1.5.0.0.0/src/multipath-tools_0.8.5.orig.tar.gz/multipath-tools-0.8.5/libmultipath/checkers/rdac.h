#ifndef _RDAC_H
#define _RDAC_H

int rdac(struct checker *);
int rdac_init(struct checker *);
void rdac_free(struct checker *);

#endif /* _RDAC_H */
