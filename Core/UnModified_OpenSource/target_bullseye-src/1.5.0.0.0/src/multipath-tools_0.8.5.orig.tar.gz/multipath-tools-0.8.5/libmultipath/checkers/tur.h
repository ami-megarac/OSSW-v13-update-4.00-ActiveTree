#ifndef _TUR_H
#define _TUR_H

int tur (struct checker *);
int tur_init (struct checker *);
void tur_free (struct checker *);

#endif /* _TUR_H */
