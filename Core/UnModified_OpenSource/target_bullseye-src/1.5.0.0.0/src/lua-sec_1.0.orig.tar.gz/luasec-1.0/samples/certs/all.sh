#!/usr/bin/env sh
./rootA.sh
./rootB.sh
./clientA.sh
./clientB.sh
./serverA.sh
./serverB.sh
