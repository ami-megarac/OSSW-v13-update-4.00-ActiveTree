main (argc, argv)
int argc;
char *argv[];
{
    printf ("argv[0] = %d\n", argv[0]);
    /*
     *	Rest of program
     */
    printf ("== done ==\n");
}
