Interaction with Locally Installed Python Versions
==================================================

As long as you don't install other versions of Python in your path,
Debian's Python versions won't be affected by a new version.

If you install a different micro version of the version of Python you
have got installed, you will need to be careful to install all the
modules you use for that version of Python too.
