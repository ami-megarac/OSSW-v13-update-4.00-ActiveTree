/*
 * C Template objects.
 *
 * Copyright (C) 2010 Marcelo Roberto Jimenez <mroberto@users.sourceforge.net>
 */

/*!
 * \file
 */

#undef EXPAND_CLASS_MEMBER_INT
#undef EXPAND_CLASS_MEMBER_BUFFER
#undef EXPAND_CLASS_MEMBER_LIST
#undef EXPAND_CLASS_MEMBER_OBJECT
#undef EXPAND_CLASS_MEMBER_STRING
#undef EXPAND_CLASS_MEMBER_DOMSTRING

