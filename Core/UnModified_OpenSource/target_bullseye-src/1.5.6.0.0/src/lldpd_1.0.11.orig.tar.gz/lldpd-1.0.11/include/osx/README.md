Those include headers have been stolen from `xnu-2050.18.24.tar.gz`
and slightly modified. They should be shipped with the OS or the
development tools but they are not. They are from Mac OS X 10.8.2 but
should work with previous versions just fine.

  http://www.opensource.apple.com/source/xnu/xnu-2050.18.24/
