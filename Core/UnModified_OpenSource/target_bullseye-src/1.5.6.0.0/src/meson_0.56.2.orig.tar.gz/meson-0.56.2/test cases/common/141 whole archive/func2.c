#define BUILDING_DLL

#include<mylib.h>

int func2(void) {
    return 42;
}
