static int hidden_func(void) {
    return 0;
}
