#include "pch.h"

int foo(void) {
    return 0;
}
