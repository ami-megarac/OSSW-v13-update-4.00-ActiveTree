#include"generated.h"

int main(void) {
    return THE_NUMBER != 9 || THE_ARG1 != 5 || THE_ARG2 != 33;
}
