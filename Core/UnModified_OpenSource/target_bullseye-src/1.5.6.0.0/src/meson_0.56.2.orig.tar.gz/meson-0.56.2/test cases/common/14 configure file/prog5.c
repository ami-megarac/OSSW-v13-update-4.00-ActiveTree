#include <string.h>
#include <config5.h>

int main(void) {
    return strcmp(MESSAGE, "@var2@");
}
