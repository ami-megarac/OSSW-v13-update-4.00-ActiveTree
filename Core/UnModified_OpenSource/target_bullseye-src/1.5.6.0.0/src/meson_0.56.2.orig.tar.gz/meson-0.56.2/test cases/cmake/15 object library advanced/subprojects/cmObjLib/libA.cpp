#include "libA.hpp"

#if not BUILD_AS_OBJ
#error "BUILD_AS_OBJ was not defined"
#endif

std::string getLibStr(void) {
  return "Hello World";
}
