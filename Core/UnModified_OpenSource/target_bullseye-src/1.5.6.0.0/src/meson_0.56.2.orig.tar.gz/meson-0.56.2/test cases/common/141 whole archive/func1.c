#define BUILDING_DLL

#include<mylib.h>

int func1(void) {
    return 42;
}
