int func1_in_obj(void);
int func2_in_obj(void);
int func3_in_obj(void);

int main(void) {
    return func1_in_obj() + func2_in_obj() + func3_in_obj();
}
